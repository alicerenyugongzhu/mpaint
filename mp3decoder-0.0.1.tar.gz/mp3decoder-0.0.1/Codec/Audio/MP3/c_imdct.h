#ifndef IMDCT_H
#define IMDCT_H 1

#ifdef __cplusplus
extern "C" {
#endif

void imdct(int points, double *in, double *out);

#ifdef __cplusplus
}
#endif

#endif

